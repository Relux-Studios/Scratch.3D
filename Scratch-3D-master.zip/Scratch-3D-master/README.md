# Scratch-3D

### The project is in developpement.(it's more an unfinished idea)

A 3D engine based on scratch block and WebGL.

![Scratch 3D](https://raw.githubusercontent.com/chtibizoux/Scratch-3D/master/ScreenShot.jpg)

Scratch block repository: https://github.com/scratchfoundation/scratch-blocks/

Later, you can export your project to an executable with the electron and phonegap build API.

### to do:

- Finish Blockly Modification and blocks_javascript.js
- Implément UI scene editor
- Finish Hierarchy and Inspector
- Implément 3D Editor
- Implément Paint Editor
- Implément Texturing Editor
- Implément Physic
- Implément Sounds
- Implément Animations
- Implément Custom Procedure
- Implément Web Request
- Implément FPS exemple
- Implément Simple Multiplayer
- Implément Save and Build
- Implément auther languages
